<?php
defined('_JEXEC') or die;

abstract class JHtmlJquery
{
	public static function __callStatic($_name, $_param)
	{
	}
}
